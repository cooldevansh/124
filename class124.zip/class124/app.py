from flask import Flask,jsonify,request
app=Flask(__name__)
tasks=[
    {
        'id':1,
        'title': 'school supplies',
        'done': False,

    },
    {
        'id':2,
        'title': 'read',
        'done': False,

    },
]
@app.route('/')
def hello_world():
    return "hello world"
@app.route('/get-data')
def get_task():
    return jsonify({"data": tasks})
if(__name__=="__main__"):
    app.run(debug=True)